---
name: Welcome to the Team
about: Describe this issue template's purpose here.

---

## Features

## Mock up if possible 


## See Sample

![part 1](https://user-images.githubusercontent.com/11560987/37249256-d699b95a-24a9-11e8-98a2-dc04e1098151.PNG)
![part 2](https://user-images.githubusercontent.com/11560987/37249258-d7d1004e-24a9-11e8-8bf1-e51c95b98da8.PNG)
![navigation drawer](https://user-images.githubusercontent.com/11560987/37249262-e448b718-24a9-11e8-93ce-b884e895ab19.png)
