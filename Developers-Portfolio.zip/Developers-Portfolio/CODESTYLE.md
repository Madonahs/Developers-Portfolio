Please Let's Follow this [GuideLines](https://google.github.io/styleguide/javaguide.html)
