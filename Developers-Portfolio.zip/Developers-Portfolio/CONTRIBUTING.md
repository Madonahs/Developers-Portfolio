# Workflow

## Building Devs-Portfolio-App
For new members please ask for the Config files: you can email me at madonahsyombua@gmail.com, the app can not run without them. The following are some additional information and guidelines to help you contribute easily.

I will encourage that you go through the app first and and get comfortable with it, see what functions are availabe, if you notice something missing or notice a bug you can suggest a fix. So you will do this by reporting issues and bugs on the issue section and use the appropriate tag, as for the pull request please make sure you give a detailed pull requests.The project is friendly and you should feel free to bring in new ideas. 

## Have Any Questions
If you have any questions and would love more info please feel free to email me  -- madonahsyombua@gmail.com. See what has been done on the project board,- [Board](https://github.com/Madonahs/Devs-Portfolio-App/projects/2)

### Warnings
Please make sure you run the app and check for warning and errors.If the warnings can be suppressed you can use @SuppressWarnings("type-of-warning").

## Additional contributing guidelines:
https://gist.github.com/PurpleBooth/b24679402957c63ec426

## Welcome
Thank you in advance.
